Toto je staršia verzia **Preteky lodí**. V tomto momente stránka projektov neposkytuje najnovší obsah a užívateľské vlastnosti. Tie budú dočasne dostupné v [tomto formáte](images/Boat Race.pdf) pred ich archiváciou.

Potrebujeme Vašu pomoc pri aktualizácii a preklade týchto projektov! Ak nám viete pomôcť, prosím [dajte nám vedieť](https://rpf.io/translators).

![Tracking pixel](https://code.org/api/hour/begin_codeclub_boatrace.png)
