Ovo je starija verzija **Utrka brodovima**. Trenutačno ne uključuje najnovije sadržaje ni korisničke značajke web stranice projekata.  Projekt će biti privremeno dostupan u [ovom](images/Boat Race.pdf) formatu prije nego se arhivira.

Trebamo vašu pomoć kako bi ažurirali i preveli ovakve projekte!  Ako ste nam u mogućnosti pomoći, molimo [javite nam se ovdje](https://rpf.io/translators).

![Tracking pixel](https://code.org/api/hour/begin_codeclub_boatrace.png)
