Dette er en ældre version af **Bådsejlads**. I øjeblikket omfatter det ikke det nyeste indhold eller brugerfunktioner fra projektets websted.  Det vil være midlertidigt tilgængelig i [dette format](images/Boat Race.pdf) før arkiveringen.

Vi har brug for din hjælp med at opdatere og oversætte projekter som dette! hvis du har mulighed for at hjælp os, så [las os det vide her](https://rpf.io/translators).

![Tracking pixel](https://code.org/api/hour/begin_codeclub_boatrace.png)
