Toto je starší verze **Závod lodí**. V této chvíli neobsahuje nejnovější obsah ani uživatelsky přívětivé funkce webu projektů. Před archivací bude tento projekt dočasně k dispozici ve starém formátu [zde](images/Boat Race.pdf).

Potřebujeme vaši pomoc při aktualizaci a překladu projektů! Pokud nám chcete pomoci, prosím [dejte nám vědět](https://rpf.io/translators).

![Tracking pixel](https://code.org/api/hour/begin_codeclub_boatrace.png)
